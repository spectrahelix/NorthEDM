import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";

export async function POST(req: Request) {
  try {
    const data = await req.json();

    const { error } = await supabase.from("requests").insert([
      {
        name: data.name,
        email: data.email,
        service_type: data.serviceType,
        description: data.description,
        urgency: data.urgency || null,
        budget: data.budget || null,
      },
    ]);

    if (error) {
      console.error("SUPABASE INSERT ERROR:", error);

      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Request submitted successfully.",
    });
  } catch (error) {
    console.error("REQUEST API ERROR:", error);

    return NextResponse.json(
      { success: false, error: "Server error." },
      { status: 500 }
    );
  }
}