import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";

export async function POST(req: Request) {
  try {
    const data = await req.json();

    const { error } = await supabase.from("bookings").insert([
      {
        name: data.name,
        email: data.email,
        group_size: Number(data.groupSize),
        preferred_date: data.date,
        notes: data.notes || null,
      },
    ]);

    if (error) {
      console.error("SUPABASE INSERT ERROR:", error);

      return NextResponse.json(
        {
          success: false,
          error: error.message,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Booking saved successfully.",
    });
  } catch (error) {
    console.error("BOOKING API ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        error: "Server error.",
      },
      { status: 500 }
    );
  }
}