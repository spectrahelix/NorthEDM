import Link from "next/link";

const categories = [
  {
    title: "Mushrooms",
    description:
      "Foraged, culinary, dried, powdered, and specialty mushroom offerings.",
  },
  {
    title: "Holistic Goods",
    description:
      "Nature-rooted wellness goods, body products, and handcrafted items.",
  },
  {
    title: "Art & Crafts",
    description:
      "Creative work, handmade art, trinkets, festival expression, and decor.",
  },
  {
    title: "Festival Gear",
    description:
      "Useful and expressive gear for music, travel, events, and lifestyle.",
  },
  {
    title: "Animal & Homestead",
    description:
      "Feeders, isopods, colony-related offerings, and practical small-scale goods.",
  },
  {
    title: "Workshops & Experiences",
    description:
      "Foraging tours, educational sessions, skill-sharing, and immersive experiences.",
  },
];

const founderItems = [
  {
    title: "Foraged Mushroom Inventory",
    description:
      "A future collection of foraged and prepared mushroom products offered through the founder vendor line.",
  },
  {
    title: "Ant Colonies & Isopods",
    description:
      "Specialty insect and colony offerings, including isopods and related raising inventory.",
  },
  {
    title: "Guided Foraging Experiences",
    description:
      "Book practical Appalachian mushroom walks and educational woodland experiences.",
  },
];

export default function MarketplacePage() {
  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100">
      <section className="border-b border-white/10">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="mb-4 text-sm uppercase tracking-[0.3em] text-green-300">
            Marketplace
          </p>

          <h1 className="max-w-4xl text-5xl font-semibold leading-tight md:text-7xl">
            A growing ecosystem of goods, culture, and local value.
          </h1>

          <p className="mt-6 max-w-3xl text-lg leading-8 text-neutral-300">
            NorthEDM Marketplace is being built as a hub for vendors, creators,
            suppliers, and founder-led offerings across the Northeast. This is
            where products, experiences, and community value start to connect.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              href="/vendors/apply"
              className="rounded-2xl bg-green-400 px-6 py-3 font-medium text-black transition hover:scale-[1.02]"
            >
              Apply as a Vendor
            </Link>

            <Link
              href="/requests"
              className="rounded-2xl border border-white/15 px-6 py-3 font-medium text-white transition hover:bg-white/5"
            >
              Submit a Request
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="mb-8">
          <p className="text-sm uppercase tracking-[0.3em] text-neutral-400">
            Categories
          </p>
          <h2 className="mt-3 text-3xl font-semibold">Marketplace lanes</h2>
          <p className="mt-3 max-w-2xl text-neutral-300">
            These categories define the early structure of the platform as we
            expand vendor intake and product visibility.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {categories.map((category) => (
            <div
              key={category.title}
              className="rounded-3xl border border-white/10 bg-white/[0.03] p-6"
            >
              <h3 className="text-2xl font-semibold">{category.title}</h3>
              <p className="mt-3 leading-7 text-neutral-300">
                {category.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-white/10 bg-white/[0.02]">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <div className="mb-8">
            <p className="text-sm uppercase tracking-[0.3em] text-purple-300">
              Founder Collection
            </p>
            <h2 className="mt-3 text-3xl font-semibold">
              Founder-led products and experiences
            </h2>
            <p className="mt-3 max-w-2xl text-neutral-300">
              The marketplace begins with the founder participating in the same
              ecosystem being built for others — setting the tone, quality, and
              authenticity of the platform.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {founderItems.map((item) => (
              <div
                key={item.title}
                className="rounded-3xl border border-white/10 bg-neutral-950 p-6"
              >
                <h3 className="text-2xl font-semibold">{item.title}</h3>
                <p className="mt-3 leading-7 text-neutral-300">
                  {item.description}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <Link
              href="/foraging"
              className="rounded-2xl bg-purple-400 px-6 py-3 font-medium text-black transition hover:opacity-90"
            >
              Explore Foraging
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-8">
          <p className="text-sm uppercase tracking-[0.3em] text-green-300">
            Vendor Network
          </p>
          <h2 className="mt-3 text-3xl font-semibold">
            Public vendors, private suppliers, and featured partners
          </h2>
          <p className="mt-4 max-w-3xl leading-8 text-neutral-300">
            NorthEDM is being designed to support multiple vendor paths: private
            supplier relationships, public marketplace listings, and featured
            vendor placement for standout contributors. This structure helps the
            platform grow without forcing every participant into the same model.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              href="/vendors/apply"
              className="rounded-2xl bg-green-400 px-6 py-3 font-medium text-black transition hover:scale-[1.02]"
            >
              Become a Vendor
            </Link>

            <Link
              href="/admin"
              className="rounded-2xl border border-white/15 px-6 py-3 font-medium text-white transition hover:bg-white/5"
            >
              Admin Hub
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}